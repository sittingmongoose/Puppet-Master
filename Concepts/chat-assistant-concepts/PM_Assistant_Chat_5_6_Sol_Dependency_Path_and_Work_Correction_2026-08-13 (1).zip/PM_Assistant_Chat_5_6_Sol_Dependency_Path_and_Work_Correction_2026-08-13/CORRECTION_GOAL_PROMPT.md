/goal
Correct the existing 5.6 Sol Puppet Master Assistant Chat creative-bakeoff work after a packet dependency, path, and manifest audit.

Use the original 5.6 Sol packet with this correction. Do not inspect other agents' concepts. Read `00_READ_ME_FIRST.md`, `PROVIDER_CLI_FINAL_ADJUDICATION.md`, the demo contracts, `REFERENCE_PATH_FIXES.md`, all raw videos/contact sheets/keyframes, PMConcept7 screenshots, and the restored machine-data aliases.

First return the platform's normal implementation plan and wait for my approval. After approval, continue all correction, rework, and testing under this same Goal.

This is not a file-copy exercise. The dependency omission may have caused implementation or concept omissions. Inspect what was actually built, identify which missing or mispathed references were not reviewed, and correct every resulting behavioral, visual, motion, data, test, Plan-impact, Command-ID, Wiring, or DRY shortcoming within your authorized scope. Do not claim the work was already covered without exact evidence.

Do not merely add missing files to a report. Establish what sources were actually reviewed. If any concept was designed without the videos, screenshots, demo manifests, trigger contract, or machine references, revisit its spatial architecture, motion story, questionnaire, activity compression, pinning, artifacts, demo density, and test coverage.

Required:
- `reference-review-report.json` lists every video, contact sheet, keyframe set, screenshot, JSON fixture, and restored alias opened, plus exact concept impact;
- preserve eight genuinely different window concepts, eight thread concepts, and all 64 pairings;
- keep concepts visually independent from other agents and from each other;
- prove causal film-level motion and a complete reduced-motion equivalent;
- repair any nonfunctional pin, artifact, question, Goal, child, diff, selector, BSD, branch, redirect, offline/replay, warning, or attachment state;
- apply final explicit provider-CLI acquisition policy;
- rerun the full interaction/visual matrix, including non-showcase pairings and long/dense/error states.

Use the restored canonical alias paths instead of silently ignoring broken references. Update concept theses, motion storyboards, demo-trigger report, impact/Plan/Command/Wiring/DRY registers, visual matrix, and known gaps.

Do not edit PMConcept7 or canon. Finish with changed paths, exact reference-review evidence, tests, remaining limitations, and whether the packet defects materially changed the concepts. Do not recommend a winner.
