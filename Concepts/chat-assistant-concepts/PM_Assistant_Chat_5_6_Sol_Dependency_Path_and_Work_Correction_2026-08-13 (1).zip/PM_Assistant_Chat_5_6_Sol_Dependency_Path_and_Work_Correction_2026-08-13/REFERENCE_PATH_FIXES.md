# Reference Path Fixes

The correction packet restores these paths used by preserved source documents:

```text
machine/requirements.json
machine/demoData.json
machine/testMatrix.json
machine/relevantPlanUnits.json
machine/sourceInventory.json
machine/videoTimeline.json
reference/pm7_chat_open.png
reference/pm7_popout.png
```

They are compatibility aliases of the `original_*` files or `reference/screenshots/*` files in the original packet; their content is not a new requirement.

All four videos, contact sheets, keyframes, and `VIDEO_SOURCE_MAP.json` are republished under `reference/videos/` so a missing path is not a valid reason to skip them.

The correction manifest intentionally excludes itself from its own file hash table. Do not copy the old self-hash pattern into concept deliverables.
